"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import ProductCard from "@/components/product-card"
import { getAllProducts, getCategories, getCertifications } from "@/lib/data"
import { Search, SlidersHorizontal } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function ProductsPage() {
  const allProducts = getAllProducts()
  const categories = getCategories()
  const certifications = getCertifications()

  const [products, setProducts] = useState(allProducts)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategories, setSelectedCategories] = useState([])
  const [selectedCertifications, setSelectedCertifications] = useState([])
  const [priceRange, setPriceRange] = useState([0, 1000000])
  const [sortBy, setSortBy] = useState("featured")

  // Filter products based on selected filters
  useEffect(() => {
    let filtered = allProducts

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Category filter
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((product) => selectedCategories.includes(product.category))
    }

    // Certification filter
    if (selectedCertifications.length > 0) {
      filtered = filtered.filter((product) =>
        product.certifications.some((cert) => selectedCertifications.includes(cert)),
      )
    }

    // Price range filter
    filtered = filtered.filter((product) => product.price >= priceRange[0] && product.price <= priceRange[1])

    // Sort products
    switch (sortBy) {
      case "price-low":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "rating":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        break
      default:
        filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0))
    }

    setProducts(filtered)
  }, [searchTerm, selectedCategories, selectedCertifications, priceRange, sortBy, allProducts])

  const handleCategoryChange = (category) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const handleCertificationChange = (certification) => {
    setSelectedCertifications((prev) =>
      prev.includes(certification) ? prev.filter((c) => c !== certification) : [...prev, certification],
    )
  }

  return (
    <main className="flex-1 py-8">
      <div className="container px-4 md:px-6">
        <h1 className="text-3xl font-bold tracking-tight mb-6">Semua Produk</h1>

        {/* Search and Sort Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Cari produk..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Urutkan" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Unggulan</SelectItem>
                <SelectItem value="price-low">Harga: Rendah ke Tinggi</SelectItem>
                <SelectItem value="price-high">Harga: Tinggi ke Rendah</SelectItem>
                <SelectItem value="rating">Rating Tertinggi</SelectItem>
                <SelectItem value="newest">Terbaru</SelectItem>
              </SelectContent>
            </Select>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="md:hidden">
                  <SlidersHorizontal className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <div className="py-4">
                  <h3 className="text-lg font-semibold mb-4">Filter Produk</h3>
                  {/* Mobile Filters */}
                  <div className="space-y-6">
                    {/* Categories */}
                    <div>
                      <h4 className="font-medium mb-3">Kategori</h4>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <div key={category.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`mobile-category-${category.id}`}
                              checked={selectedCategories.includes(category.id)}
                              onCheckedChange={() => handleCategoryChange(category.id)}
                            />
                            <Label htmlFor={`mobile-category-${category.id}`}>{category.name}</Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Certifications */}
                    <div>
                      <h4 className="font-medium mb-3">Sertifikasi</h4>
                      <div className="space-y-2">
                        {certifications.map((cert) => (
                          <div key={cert.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={`mobile-cert-${cert.id}`}
                              checked={selectedCertifications.includes(cert.id)}
                              onCheckedChange={() => handleCertificationChange(cert.id)}
                            />
                            <Label htmlFor={`mobile-cert-${cert.id}`}>{cert.name}</Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Price Range */}
                    <div>
                      <h4 className="font-medium mb-3">Rentang Harga</h4>
                      <div className="space-y-4">
                        <Slider
                          defaultValue={[0, 1000000]}
                          max={1000000}
                          step={10000}
                          value={priceRange}
                          onValueChange={setPriceRange}
                        />
                        <div className="flex justify-between">
                          <span>Rp{priceRange[0].toLocaleString()}</span>
                          <span>Rp{priceRange[1].toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Desktop Sidebar Filters */}
          <div className="hidden md:block w-64 space-y-6">
            <h3 className="text-lg font-semibold mb-4">Filter Produk</h3>

            {/* Categories */}
            <div>
              <h4 className="font-medium mb-3">Kategori</h4>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`category-${category.id}`}
                      checked={selectedCategories.includes(category.id)}
                      onCheckedChange={() => handleCategoryChange(category.id)}
                    />
                    <Label htmlFor={`category-${category.id}`}>{category.name}</Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Certifications */}
            <div>
              <h4 className="font-medium mb-3">Sertifikasi</h4>
              <div className="space-y-2">
                {certifications.map((cert) => (
                  <div key={cert.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`cert-${cert.id}`}
                      checked={selectedCertifications.includes(cert.id)}
                      onCheckedChange={() => handleCertificationChange(cert.id)}
                    />
                    <Label htmlFor={`cert-${cert.id}`}>{cert.name}</Label>
                  </div>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <h4 className="font-medium mb-3">Rentang Harga</h4>
              <div className="space-y-4">
                <Slider
                  defaultValue={[0, 1000000]}
                  max={1000000}
                  step={10000}
                  value={priceRange}
                  onValueChange={setPriceRange}
                />
                <div className="flex justify-between">
                  <span>Rp{priceRange[0].toLocaleString()}</span>
                  <span>Rp{priceRange[1].toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Product Grid */}
          <div className="flex-1">
            {products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-medium mb-2">Tidak ada produk yang ditemukan</h3>
                <p className="text-muted-foreground">Coba ubah filter pencarian Anda</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
