"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/components/auth-provider"
import { CheckCircle } from "lucide-react"
import { useRouter } from "next/navigation"

export default function CheckoutPage() {
  const { cart, clearCart } = useCart()
  const { toast } = useToast()
  const { user } = useAuth()
  const router = useRouter()
  const [orderComplete, setOrderComplete] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 0 ? 15000 : 0
  const tax = Math.round(subtotal * 0.11) // 11% tax
  const total = subtotal + shipping + tax

  const [formData, setFormData] = useState({
    fullName: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    address: user?.address || "",
    city: user?.city || "",
    postalCode: user?.postalCode || "",
    province: user?.province || "",
    notes: "",
    paymentMethod: "bank_transfer",
    shippingMethod: "regular",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setIsLoading(true)

    if (cart.length === 0) {
      toast({
        title: "Keranjang kosong",
        description: "Tambahkan produk ke keranjang sebelum melanjutkan ke pembayaran.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Validate form
    const requiredFields = ["fullName", "email", "phone", "address", "city", "postalCode", "province"]
    const emptyFields = requiredFields.filter((field) => !formData[field])

    if (emptyFields.length > 0) {
      toast({
        title: "Form belum lengkap",
        description: "Harap lengkapi semua field yang diperlukan.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    // Process order
    try {
      // Simulate API call
      setTimeout(() => {
        setOrderComplete(true)
        clearCart()
        setIsLoading(false)
      }, 1500)
    } catch (error) {
      console.error("Error processing order:", error)
      toast({
        title: "Terjadi kesalahan",
        description: "Gagal memproses pesanan. Silakan coba lagi.",
        variant: "destructive",
      })
      setIsLoading(false)
    }
  }

  // Redirect to cart if cart is empty
  if (cart.length === 0 && !orderComplete) {
    return (
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6 max-w-3xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-4">Keranjang Belanja Kosong</h1>
          <p className="text-muted-foreground mb-8">
            Anda belum menambahkan produk ke keranjang belanja. Silakan tambahkan produk terlebih dahulu.
          </p>
          <Button asChild>
            <Link href="/products">Jelajahi Produk</Link>
          </Button>
        </div>
      </main>
    )
  }

  if (orderComplete) {
    return (
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6 max-w-3xl mx-auto text-center">
          <div className="mb-8">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
          </div>
          <h1 className="text-3xl font-bold mb-4">Pesanan Berhasil!</h1>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            Terima kasih telah berbelanja di AgroOrganik. Pesanan Anda telah berhasil diproses dan sedang disiapkan
            untuk pengiriman.
          </p>

          <div className="bg-muted p-4 rounded-lg mb-8 inline-block">
            <h2 className="font-semibold">Nomor Pesanan: #AGO12345</h2>
          </div>

          <div className="space-y-6 mb-8 text-left">
            <div className="border rounded-lg p-4">
              <h3 className="font-semibold mb-2">Detail Pengiriman</h3>
              <div className="text-sm space-y-1">
                <p>
                  <span className="text-muted-foreground">Nama:</span> {formData.fullName}
                </p>
                <p>
                  <span className="text-muted-foreground">Alamat:</span> {formData.address}
                </p>
                <p>
                  <span className="text-muted-foreground">Kota:</span> {formData.city}
                </p>
                <p>
                  <span className="text-muted-foreground">Provinsi:</span> {formData.province}
                </p>
                <p>
                  <span className="text-muted-foreground">Kode Pos:</span> {formData.postalCode}
                </p>
                <p>
                  <span className="text-muted-foreground">Telepon:</span> {formData.phone}
                </p>
              </div>
            </div>

            <div className="border rounded-lg p-4">
              <h3 className="font-semibold mb-2">Metode Pembayaran</h3>
              <p className="text-sm capitalize">{formData.paymentMethod.replace("_", " ")}</p>
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-100 rounded-md text-sm">
                <p className="font-medium text-yellow-800">Instruksi Pembayaran</p>
                <p className="mt-1 text-yellow-700">
                  Silakan transfer ke rekening BCA 1234567890 a.n. PT AgroOrganik Indonesia sebesar Rp
                  {total.toLocaleString()} dalam 24 jam.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild variant="outline">
              <Link href="/account/orders">Lihat Pesanan Saya</Link>
            </Button>
            <Button asChild>
              <Link href="/products">Lanjutkan Belanja</Link>
            </Button>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="flex-1 py-8">
      <div className="container px-4 md:px-6">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <form onSubmit={handleSubmit}>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-8">
              {/* Shipping Information */}
              <div className="border rounded-lg p-6 space-y-4">
                <h2 className="text-xl font-semibold">Informasi Pengiriman</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Nama Lengkap *</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Nomor Telepon *</Label>
                    <Input id="phone" name="phone" value={formData.phone} onChange={handleInputChange} required />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="address">Alamat *</Label>
                    <Textarea
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="province">Provinsi *</Label>
                    <Select value={formData.province} onValueChange={(value) => handleSelectChange("province", value)}>
                      <SelectTrigger id="province">
                        <SelectValue placeholder="Pilih provinsi" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jawa_barat">Jawa Barat</SelectItem>
                        <SelectItem value="jawa_tengah">Jawa Tengah</SelectItem>
                        <SelectItem value="jawa_timur">Jawa Timur</SelectItem>
                        <SelectItem value="dki_jakarta">DKI Jakarta</SelectItem>
                        <SelectItem value="banten">Banten</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="city">Kota/Kabupaten *</Label>
                    <Input id="city" name="city" value={formData.city} onChange={handleInputChange} required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Kode Pos *</Label>
                    <Input
                      id="postalCode"
                      name="postalCode"
                      value={formData.postalCode}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="notes">Catatan (opsional)</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Instruksi khusus untuk pengiriman"
                      value={formData.notes}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>

              {/* Shipping Method */}
              <div className="border rounded-lg p-6 space-y-4">
                <h2 className="text-xl font-semibold">Metode Pengiriman</h2>

                <RadioGroup
                  value={formData.shippingMethod}
                  onValueChange={(value) => handleSelectChange("shippingMethod", value)}
                >
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="regular" id="regular" />
                    <Label htmlFor="regular" className="flex-1 cursor-pointer">
                      <div className="font-medium">Reguler (2-3 hari)</div>
                      <div className="text-sm text-muted-foreground">Rp15.000</div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="express" id="express" />
                    <Label htmlFor="express" className="flex-1 cursor-pointer">
                      <div className="font-medium">Express (1-2 hari)</div>
                      <div className="text-sm text-muted-foreground">Rp30.000</div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="same_day" id="same_day" />
                    <Label htmlFor="same_day" className="flex-1 cursor-pointer">
                      <div className="font-medium">Same Day (Hari ini)</div>
                      <div className="text-sm text-muted-foreground">Rp50.000</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Payment Method */}
              <div className="border rounded-lg p-6 space-y-4">
                <h2 className="text-xl font-semibold">Metode Pembayaran</h2>

                <RadioGroup
                  value={formData.paymentMethod}
                  onValueChange={(value) => handleSelectChange("paymentMethod", value)}
                >
                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="bank_transfer" id="bank_transfer" />
                    <Label htmlFor="bank_transfer" className="flex-1 cursor-pointer">
                      <div className="font-medium">Transfer Bank</div>
                      <div className="text-sm text-muted-foreground">BCA, BNI, BRI, Mandiri</div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="e_wallet" id="e_wallet" />
                    <Label htmlFor="e_wallet" className="flex-1 cursor-pointer">
                      <div className="font-medium">E-Wallet</div>
                      <div className="text-sm text-muted-foreground">OVO, GoPay, DANA, LinkAja</div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="credit_card" id="credit_card" />
                    <Label htmlFor="credit_card" className="flex-1 cursor-pointer">
                      <div className="font-medium">Kartu Kredit</div>
                      <div className="text-sm text-muted-foreground">Visa, Mastercard, JCB</div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 border rounded-md p-3">
                    <RadioGroupItem value="cod" id="cod" />
                    <Label htmlFor="cod" className="flex-1 cursor-pointer">
                      <div className="font-medium">Bayar di Tempat (COD)</div>
                      <div className="text-sm text-muted-foreground">Hanya tersedia untuk area tertentu</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <div className="border rounded-lg p-4 space-y-4 sticky top-4">
                <h2 className="text-lg font-semibold">Ringkasan Pesanan</h2>

                <div className="max-h-60 overflow-y-auto space-y-3">
                  {cart.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="relative w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src={item.image || "/placeholder.svg?height=64&width=64"}
                          alt={item.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{item.name}</h4>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm text-muted-foreground">
                            {item.quantity} x Rp{item.price.toLocaleString()}
                          </span>
                          <span className="font-medium">Rp{(item.price * item.quantity).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>Rp{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pengiriman</span>
                    <span>Rp{shipping.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pajak (11%)</span>
                    <span>Rp{tax.toLocaleString()}</span>
                  </div>
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>Rp{total.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Memproses..." : "Selesaikan Pesanan"}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  Dengan melanjutkan, Anda menyetujui Syarat dan Ketentuan serta Kebijakan Privasi kami.
                </p>
              </div>
            </div>
          </div>
        </form>
      </div>
    </main>
  )
}
