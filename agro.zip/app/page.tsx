import Link from "next/link"
import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"
import CategorySection from "@/components/category-section"
import HeroSection from "@/components/hero-section"
import { getFeaturedProducts, getCategories } from "@/lib/data"

export default function Home() {
  const featuredProducts = getFeaturedProducts()
  const categories = getCategories()

  return (
    <main className="flex-1">
      <HeroSection />

      {/* Categories Section */}
      <section className="py-12 bg-green-50">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-8">Kategori Produk</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((category) => (
              <CategorySection key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12">
        <div className="container px-4 md:px-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold tracking-tight">Produk Unggulan</h2>
            <Link href="/products">
              <Button variant="outline">Lihat Semua</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Certification Partners */}
      <section className="py-12 bg-green-50">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-8">Lembaga Sertifikasi Terpercaya</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160"
                alt="Organik Indonesia"
                className="h-20 w-40 object-contain"
              />
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <img src="/placeholder.svg?height=80&width=160" alt="Sucofindo" className="h-20 w-40 object-contain" />
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <img src="/placeholder.svg?height=80&width=160" alt="BPOM" className="h-20 w-40 object-contain" />
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160"
                alt="Kementerian Pertanian"
                className="h-20 w-40 object-contain"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-12">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-8">Mengapa Memilih AgroOrganik?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-green-100 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Produk Tersertifikasi</h3>
              <p className="text-gray-600">
                Semua produk telah melalui proses sertifikasi ketat dari lembaga terpercaya
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-green-100 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Kualitas Terjamin</h3>
              <p className="text-gray-600">Rating kualitas transparan dari lembaga independen untuk setiap produk</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-green-100 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 text-green-600"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Produk Lokal</h3>
              <p className="text-gray-600">Mendukung petani dan produsen lokal dengan produk berkualitas tinggi</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
