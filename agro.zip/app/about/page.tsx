import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle, Users, Leaf, Shield } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-green-400 opacity-90" />
        <div className="relative container px-4 md:px-6 py-20 md:py-32 flex flex-col items-center text-center text-white">
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-6">Tentang AgroOrganik</h1>
          <p className="text-lg md:text-xl max-w-3xl mb-8">
            Marketplace khusus produk agroorganik dan biopestisida lokal dengan sertifikasi dan rating kualitas dari
            lembaga terpercaya untuk hasil pertanian yang lebih sehat dan berkelanjutan.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight mb-6">Cerita Kami</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  AgroOrganik didirikan pada tahun 2020 oleh sekelompok petani dan ahli pertanian yang peduli dengan
                  keberlanjutan dan kesehatan lingkungan. Kami melihat adanya kesenjangan antara produsen produk
                  pertanian organik lokal yang berkualitas dengan konsumen yang mencari produk-produk tersebut.
                </p>
                <p>
                  Visi kami adalah menjadi platform terdepan yang menghubungkan petani dan produsen lokal dengan
                  konsumen yang peduli akan kesehatan dan lingkungan. Kami berkomitmen untuk menyediakan produk
                  agroorganik dan biopestisida berkualitas tinggi yang telah tersertifikasi oleh lembaga terpercaya.
                </p>
                <p>
                  Melalui AgroOrganik, kami tidak hanya menyediakan marketplace, tetapi juga membangun ekosistem
                  pertanian organik yang berkelanjutan di Indonesia. Kami bekerja sama dengan petani lokal, lembaga
                  sertifikasi, dan komunitas pertanian untuk memastikan produk yang kami tawarkan memenuhi standar
                  kualitas tertinggi.
                </p>
              </div>
            </div>
            <div className="relative aspect-video rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600&text=Tentang+Kami"
                alt="Tim AgroOrganik"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-16 bg-green-50">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-6">Misi Kami</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-12">
            Kami berkomitmen untuk mendukung pertanian organik berkelanjutan dan menyediakan akses ke produk berkualitas
            tinggi bagi semua orang.
          </p>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Mendukung Pertanian Organik</h3>
              <p className="text-muted-foreground">
                Mempromosikan dan mendukung praktik pertanian organik yang ramah lingkungan dan berkelanjutan.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Menjamin Kualitas</h3>
              <p className="text-muted-foreground">
                Memastikan semua produk memiliki sertifikasi dan rating kualitas dari lembaga terpercaya.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-3">Memberdayakan Petani Lokal</h3>
              <p className="text-muted-foreground">
                Memberikan platform bagi petani dan produsen lokal untuk menjangkau pasar yang lebih luas.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16">
        <div className="container px-4 md:px-6">
          <h2 className="text-3xl font-bold tracking-tight text-center mb-12">Nilai-Nilai Kami</h2>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Keberlanjutan</h3>
                <p className="text-muted-foreground">
                  Kami berkomitmen untuk mempromosikan praktik pertanian yang berkelanjutan dan ramah lingkungan untuk
                  generasi mendatang.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Transparansi</h3>
                <p className="text-muted-foreground">
                  Kami percaya pada transparansi dalam setiap aspek bisnis kami, dari sumber produk hingga proses
                  sertifikasi.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Kualitas</h3>
                <p className="text-muted-foreground">
                  Kami hanya menawarkan produk berkualitas tinggi yang telah melalui proses seleksi dan sertifikasi
                  ketat.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Komunitas</h3>
                <p className="text-muted-foreground">
                  Kami membangun komunitas yang mendukung pertanian organik dan gaya hidup berkelanjutan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16 bg-green-50">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-6">Tim Kami</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-12">
            Kami adalah tim yang berdedikasi untuk mendukung pertanian organik dan berkelanjutan di Indonesia.
          </p>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                name: "Ahmad Fauzi",
                role: "Pendiri & CEO",
                image: "/placeholder.svg?height=300&width=300&text=AF",
              },
              {
                name: "Siti Rahayu",
                role: "Kepala Operasional",
                image: "/placeholder.svg?height=300&width=300&text=SR",
              },
              {
                name: "Budi Santoso",
                role: "Ahli Pertanian",
                image: "/placeholder.svg?height=300&width=300&text=BS",
              },
              {
                name: "Dewi Lestari",
                role: "Manajer Kualitas",
                image: "/placeholder.svg?height=300&width=300&text=DL",
              },
            ].map((member, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <div className="relative w-32 h-32 rounded-full overflow-hidden mx-auto mb-4">
                  <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
                </div>
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-muted-foreground">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certification Partners */}
      <section className="py-16">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-6">Lembaga Sertifikasi Mitra</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-12">
            Kami bekerja sama dengan lembaga sertifikasi terpercaya untuk memastikan kualitas produk yang kami tawarkan.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160&text=Organik+Indonesia"
                alt="Organik Indonesia"
                className="h-20 w-40 object-contain mx-auto"
              />
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160&text=Sucofindo"
                alt="Sucofindo"
                className="h-20 w-40 object-contain mx-auto"
              />
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160&text=BPOM"
                alt="BPOM"
                className="h-20 w-40 object-contain mx-auto"
              />
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <img
                src="/placeholder.svg?height=80&width=160&text=Kementerian+Pertanian"
                alt="Kementerian Pertanian"
                className="h-20 w-40 object-contain mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-green-600 text-white">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-6">Bergabunglah dengan Kami</h2>
          <p className="text-lg max-w-3xl mx-auto mb-8">
            Jadilah bagian dari gerakan pertanian organik dan berkelanjutan. Temukan produk berkualitas tinggi atau
            daftarkan produk Anda di AgroOrganik.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-green-600 hover:bg-gray-100">
              <Link href="/products">Jelajahi Produk</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              <Link href="/contact">Hubungi Kami</Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
