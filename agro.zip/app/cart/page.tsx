"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart()
  const { toast } = useToast()
  const [couponCode, setCouponCode] = useState("")

  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 0 ? 15000 : 0
  const discount = 0 // Will be calculated based on coupon code
  const total = subtotal + shipping - discount

  const handleQuantityChange = (productId, newQuantity) => {
    if (newQuantity < 1) return
    updateQuantity(productId, newQuantity)
  }

  const handleRemove = (productId) => {
    removeFromCart(productId)
    toast({
      title: "Produk dihapus",
      description: "Produk telah dihapus dari keranjang belanja Anda.",
    })
  }

  const applyCoupon = () => {
    if (!couponCode) return

    toast({
      title: "Kode kupon tidak valid",
      description: "Kode kupon yang Anda masukkan tidak valid atau telah kadaluarsa.",
      variant: "destructive",
    })

    // If coupon is valid, would update discount state here
  }

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Keranjang kosong",
        description: "Tambahkan produk ke keranjang sebelum melanjutkan ke pembayaran.",
        variant: "destructive",
      })
      return
    }

    // Gunakan router untuk navigasi
    window.location.href = "/checkout"
  }

  return (
    <main className="flex-1 py-8">
      <div className="container px-4 md:px-6">
        <h1 className="text-3xl font-bold mb-8">Keranjang Belanja</h1>

        {cart.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              {/* Cart Items */}
              <div className="border rounded-lg overflow-hidden">
                <div className="bg-muted px-4 py-3 font-medium grid grid-cols-12 gap-4 items-center">
                  <div className="col-span-6">Produk</div>
                  <div className="col-span-2 text-center">Harga</div>
                  <div className="col-span-2 text-center">Jumlah</div>
                  <div className="col-span-2 text-center">Subtotal</div>
                </div>

                <div className="divide-y">
                  {cart.map((item) => (
                    <div key={item.id} className="px-4 py-4 grid grid-cols-12 gap-4 items-center">
                      <div className="col-span-6 flex items-center gap-4">
                        <div className="relative w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                          <Image
                            src={item.image || "/placeholder.svg?height=64&width=64"}
                            alt={item.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium">
                            <Link href={`/products/${item.id}`} className="hover:underline">
                              {item.name}
                            </Link>
                          </h3>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {item.certifications?.slice(0, 2).map((cert) => (
                              <span key={cert} className="text-xs bg-green-100 text-green-800 px-1.5 py-0.5 rounded">
                                {cert}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 text-center">Rp{item.price.toLocaleString()}</div>

                      <div className="col-span-2 flex justify-center">
                        <div className="flex items-center border rounded-md">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          >
                            -
                          </Button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          >
                            +
                          </Button>
                        </div>
                      </div>

                      <div className="col-span-2 flex items-center justify-between">
                        <span className="font-medium">Rp{(item.price * item.quantity).toLocaleString()}</span>
                        <Button variant="ghost" size="icon" onClick={() => handleRemove(item.id)}>
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-4 justify-between">
                <Button variant="outline" asChild>
                  <Link href="/products">Lanjutkan Belanja</Link>
                </Button>
                <Button variant="outline" onClick={clearCart}>
                  Kosongkan Keranjang
                </Button>
              </div>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <div className="border rounded-lg p-4 space-y-4">
                <h2 className="text-lg font-semibold">Ringkasan Pesanan</h2>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>Rp{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Pengiriman</span>
                    <span>Rp{shipping.toLocaleString()}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Diskon</span>
                      <span>-Rp{discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 mt-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>Rp{total.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Input placeholder="Kode Kupon" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} />
                  <Button variant="outline" onClick={applyCoupon}>
                    Terapkan
                  </Button>
                </div>

                <Button className="w-full" onClick={handleCheckout}>
                  Lanjutkan ke Pembayaran
                </Button>
              </div>

              <div className="border rounded-lg p-4 space-y-2">
                <h3 className="font-medium">Metode Pembayaran</h3>
                <div className="flex flex-wrap gap-2">
                  <div className="border rounded p-2 w-16 h-10 flex items-center justify-center bg-gray-50">
                    <span className="text-xs font-medium">VISA</span>
                  </div>
                  <div className="border rounded p-2 w-16 h-10 flex items-center justify-center bg-gray-50">
                    <span className="text-xs font-medium">MC</span>
                  </div>
                  <div className="border rounded p-2 w-16 h-10 flex items-center justify-center bg-gray-50">
                    <span className="text-xs font-medium">BCA</span>
                  </div>
                  <div className="border rounded p-2 w-16 h-10 flex items-center justify-center bg-gray-50">
                    <span className="text-xs font-medium">BNI</span>
                  </div>
                  <div className="border rounded p-2 w-16 h-10 flex items-center justify-center bg-gray-50">
                    <span className="text-xs font-medium">BRI</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 space-y-4">
            <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-12 w-12 text-muted-foreground"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                />
              </svg>
            </div>
            <h2 className="text-xl font-semibold">Keranjang Belanja Kosong</h2>
            <p className="text-muted-foreground max-w-md mx-auto">
              Anda belum menambahkan produk ke keranjang belanja. Jelajahi produk-produk berkualitas kami dan temukan
              yang sesuai dengan kebutuhan Anda.
            </p>
            <Button asChild className="mt-4">
              <Link href="/products">Jelajahi Produk</Link>
            </Button>
          </div>
        )}
      </div>
    </main>
  )
}
