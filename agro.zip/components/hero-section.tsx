import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <section className="relative">
      <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-green-400 opacity-90" />
      <div className="relative container px-4 md:px-6 py-20 md:py-32 flex flex-col items-center text-center text-white">
        <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-6">
          Produk Agroorganik & Biopestisida Berkualitas
        </h1>
        <p className="text-lg md:text-xl max-w-3xl mb-8">
          Temukan produk agroorganik dan biopestisida lokal terbaik dengan sertifikasi dan rating kualitas dari lembaga
          terpercaya untuk hasil pertanian yang lebih sehat dan berkelanjutan.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button asChild size="lg" className="bg-white text-green-600 hover:bg-gray-100">
            <Link href="/products">Jelajahi Produk</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
            <Link href="/about">Pelajari Lebih Lanjut</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
