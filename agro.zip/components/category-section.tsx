import Link from "next/link"
import Image from "next/image"

export default function CategorySection({ category }) {
  return (
    <Link href={`/products?category=${category.id}`} className="group relative flex flex-col items-center text-center">
      <div className="relative w-full aspect-square overflow-hidden rounded-lg mb-3 bg-white">
        <Image
          src={category.image || `/placeholder.svg?height=200&width=200&text=${category.name}`}
          alt={category.name}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
      </div>
      <h3 className="font-medium group-hover:text-green-600 transition-colors">{category.name}</h3>
    </Link>
  )
}
