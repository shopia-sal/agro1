"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShieldCheck, Star, ShoppingCart } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

export default function ProductCard({ product }) {
  const { addToCart } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (e) => {
    e.preventDefault()
    e.stopPropagation()

    addToCart(product, 1)
    toast({
      title: "Produk ditambahkan",
      description: `${product.name} telah ditambahkan ke keranjang.`,
    })
  }

  return (
    <div className="group relative border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
      <Link href={`/products/${product.id}`} className="absolute inset-0 z-10">
        <span className="sr-only">Lihat detail {product.name}</span>
      </Link>

      {/* Product Image */}
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <Image
          src={product.image || "/placeholder.svg?height=300&width=300"}
          alt={product.name}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />

        {product.featured && <Badge className="absolute top-2 left-2 bg-green-600">Unggulan</Badge>}

        {product.discount && <Badge className="absolute top-2 right-2 bg-red-600">-{product.discount}%</Badge>}
      </div>

      {/* Product Info */}
      <div className="p-4">
        <div className="mb-2 flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={`h-4 w-4 ${
                i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
              }`}
            />
          ))}
          <span className="text-xs text-muted-foreground ml-1">({product.reviewCount})</span>
        </div>

        <h3 className="font-medium line-clamp-1">{product.name}</h3>

        <div className="mt-1 flex flex-wrap gap-1">
          {product.certifications?.slice(0, 2).map((cert) => (
            <Badge key={cert} variant="outline" className="flex items-center gap-1 text-xs">
              <ShieldCheck className="h-3 w-3" />
              {cert}
            </Badge>
          ))}
        </div>

        <div className="mt-2 flex items-center justify-between">
          <div>
            <div className="font-semibold">Rp{product.price.toLocaleString()}</div>
            {product.originalPrice && (
              <div className="text-xs text-muted-foreground line-through">
                Rp{product.originalPrice.toLocaleString()}
              </div>
            )}
          </div>

          <Button size="icon" variant="ghost" className="z-20 relative" onClick={handleAddToCart}>
            <ShoppingCart className="h-5 w-5" />
            <span className="sr-only">Tambahkan ke keranjang</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
