import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Instagram, Twitter, Youtube, Mail, MapPin, Phone, Leaf } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-green-50 border-t">
      <div className="container px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <Leaf className="h-6 w-6 text-green-600" />
              <span className="text-xl font-bold">AgroOrganik</span>
            </Link>
            <p className="text-muted-foreground">
              Marketplace khusus produk agroorganik dan biopestisida lokal dengan sertifikasi dan rating kualitas dari
              lembaga terpercaya.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Facebook className="h-4 w-4" />
                <span className="sr-only">Facebook</span>
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Instagram className="h-4 w-4" />
                <span className="sr-only">Instagram</span>
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Twitter className="h-4 w-4" />
                <span className="sr-only">Twitter</span>
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Youtube className="h-4 w-4" />
                <span className="sr-only">YouTube</span>
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Kategori</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/products?category=pupuk_organik"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Pupuk Organik
                </Link>
              </li>
              <li>
                <Link
                  href="/products?category=biopestisida"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Biopestisida
                </Link>
              </li>
              <li>
                <Link
                  href="/products?category=bibit_organik"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Bibit Organik
                </Link>
              </li>
              <li>
                <Link
                  href="/products?category=alat_pertanian"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Alat Pertanian
                </Link>
              </li>
              <li>
                <Link
                  href="/products?category=produk_olahan"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                >
                  Produk Olahan
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Informasi</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                  Tentang Kami
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  Hubungi Kami
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                  Syarat & Ketentuan
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                  Kebijakan Privasi
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Hubungi Kami</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-green-600 mt-0.5" />
                <span className="text-muted-foreground">Jl. Agro Organik No. 123, Bogor, Jawa Barat, Indonesia</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-green-600" />
                <span className="text-muted-foreground">+62 812 3456 7890</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-green-600" />
                <span className="text-muted-foreground">info@agroorganik.com</span>
              </li>
            </ul>

            <div className="space-y-2">
              <h4 className="font-medium">Berlangganan Newsletter</h4>
              <div className="flex gap-2">
                <Input placeholder="Email Anda" type="email" className="bg-white" />
                <Button>Daftar</Button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} AgroOrganik. Hak Cipta Dilindungi.
          </p>
        </div>
      </div>
    </footer>
  )
}
